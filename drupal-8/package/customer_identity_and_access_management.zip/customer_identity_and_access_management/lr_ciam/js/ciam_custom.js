jQuery(document).ready(function () {    
    initializeChangePasswordCiamForms();
    initializeTwoFactorAuthenticator();
    initializeAddEmailCiamForms();
    initializeRemoveEmailCiamForms();
    getBackupCodes();
    initializePhoneUpdate();
    initializeForgotPasswordCiamForms(); 
});

