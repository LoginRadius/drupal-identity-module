jQuery(document).ready(function () {    
    callSocialInterface(); 
});

