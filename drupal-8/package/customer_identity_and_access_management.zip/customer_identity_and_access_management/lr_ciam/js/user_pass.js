jQuery(document).ready(function () {
     jQuery('#content .tabs').attr('style', 'display:none');
});

