jQuery(document).ready(function () {
   initializeAccountLinkingCiamForms(); 
});

