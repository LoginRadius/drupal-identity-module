jQuery(document).ready(function () {  
    if(!(window.location.href.indexOf("admin") > -1)) {  
    callSocialInterface(); 
    }
});

