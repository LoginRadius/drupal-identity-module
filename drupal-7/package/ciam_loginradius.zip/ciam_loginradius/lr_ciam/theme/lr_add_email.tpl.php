<script>
    jQuery(document).ready(function () {
        initializeAddEmailCiamForms();
    });
</script>
<div id="addemail-form" class="LoginRadius_overlay" style="display: none;">        
    <div class="popupmain">           
        <div class="lr-popupheading">Add Email <div onclick="lrCloseAddEmailPopup();" class="closeRemove">x</div></div>
        <div class="ciam-lr-form popupinner" id="addemail-container">
            <div class="lr-noerror">
            </div>
        </div>
        <div class="lr-popup-footer">
        </div>
    </div>
</div>

