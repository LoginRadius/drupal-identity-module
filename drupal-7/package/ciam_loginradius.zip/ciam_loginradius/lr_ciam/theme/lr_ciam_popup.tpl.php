<?php

/**
 * @file
 * Social Login User registration popup.
*/
?>
<div id="social-registration-form" class="LoginRadius_overlay LoginRadius_content_IE" style="display: none;">
  <div class="popupmain">
    <div class="lr-popupheading"> <?php echo 'Please fill the following details to proceed' ?></div>
    <div class="ciam-lr-form popupinner" id="social-registration-container">
      <div class="lr-noerror">
      </div>
    </div>
    <div class="lr-popup-footer">
    </div>
  </div>
</div>


