 <script>
    jQuery(document).ready(function () {
      initializePhoneUpdate();
    });
  </script>
  <div class="ciam-lr-form my-form-wrapper">
    <div id="updatephone-container"></div>
  </div>
