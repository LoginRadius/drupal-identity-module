<div class="messages" style="display:none">
  <h2 class="element-invisible">Error message</h2>
  <ul>
    <li class="messageinfo">

    </li>
    <div class="clear"></div>
  </ul>
</div>

