 <script>
    jQuery(document).ready(function () {
      initializeTwoFactorAuthenticator();
    });
  </script>
  <div class="ciam-lr-form my-form-wrapper">
    <div id="authentication-container"></div>
  </div>
