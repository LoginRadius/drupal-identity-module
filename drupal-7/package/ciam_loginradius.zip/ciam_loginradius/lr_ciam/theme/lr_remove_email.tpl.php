<script>
    jQuery(document).ready(function () {
        initializeRemoveEmailCiamForms();
    });
</script>
<div id="removeemail-form" class="LoginRadius_overlay" style="display: none;">       
    <div class="popupmain">          
        <div class="lr-popupheading">Remove Email <div onclick="lrCloseRemovePopup();" class="closeRemove">x</div></div>
        <div class="ciam-lr-form popupinner" id="removeemail-container">
            <div class="lr-noerror">
            </div>
        </div>
        <div class="lr-popup-footer">
        </div>
    </div>
</div>


