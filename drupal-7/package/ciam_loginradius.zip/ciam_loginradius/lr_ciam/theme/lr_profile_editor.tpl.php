 <script>
    jQuery(document).ready(function () {
      initializeProfileUpdate();
    });
  </script>
  <div class="ciam-lr-form my-form-wrapper">
    <div id="profileeditor-container" style="display: block;"></div>
  </div>
